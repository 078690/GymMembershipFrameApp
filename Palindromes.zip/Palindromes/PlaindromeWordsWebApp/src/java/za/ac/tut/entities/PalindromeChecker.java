/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.entities;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 *
 * @author BEAST I5
 */
public class PalindromeChecker implements PalindromeInterfaceChecker{

    @Override
    public synchronized boolean wordLength(String word) {
       boolean ans = false;
       
       if(word.length()==3){
           ans = true;
       }
       return ans;
    }

    @Override
    public boolean checkPalindrome(String word, HttpServletRequest request) {
        HttpSession session = request.getSession();
        Integer cnt = (int)session.getAttribute("cnt");
        Integer correctPalin = (int)session.getAttribute("correctPalin");
        Integer incorrectPalin = (int)session.getAttribute("incorrectPalin");
        boolean ans = false;
        String words = "";
        
        for(int x = word.length()-1;x>=0;x--){
            words += word.charAt(x);
        }
        
        if(words.equals(word)){
            ans = true;
            correctPalin++;
            session.setAttribute("correctPalin", correctPalin);
        }else{
            incorrectPalin++;
            session.setAttribute("incorrectPalin", incorrectPalin);
        }
        cnt++;
        session.setAttribute("cnt", cnt);
                
        return ans;
    }
    
}
