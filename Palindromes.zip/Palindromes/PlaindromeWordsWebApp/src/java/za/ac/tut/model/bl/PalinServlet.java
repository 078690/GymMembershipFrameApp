/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model.bl;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.entities.PalindromeChecker;

/**
 *
 * @author BEAST I5
 */
public class PalinServlet extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
       
        String words = request.getParameter("word");
        String outcome = "";
        
      
        
        PalindromeChecker pc = new PalindromeChecker();
        
        if(pc.wordLength(words)){
            if(pc.checkPalindrome(words, request)){
                outcome = "Palindrome";
            }else{
                outcome = "not a palindrome";
            }
            request.setAttribute("outcome", outcome);
            
            RequestDispatcher dispo = request.getRequestDispatcher("outcomePal.jsp");
            dispo.forward(request, response);
        }else{
            response.sendRedirect("menu.html");
        }
        
    }// </editor-fold>
}
