/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model.bl;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author BEAST I5
 */
public class startSession extends HttpServlet {


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         HttpSession session = request.getSession(true);
         
         createConnect(session);
         
         RequestDispatcher dispo = request.getRequestDispatcher("menu.html");
         dispo.forward(request, response);
    }

    private void createConnect(HttpSession session) {
     
       int cnt = 0;
       int correctPalin = 0;
       int incorrectPalin = 0;
       
       session.setAttribute("cnt", cnt);
       session.setAttribute("correctPalin", correctPalin);
       session.setAttribute("incorrectPalin", incorrectPalin);
  
       
    }
}
