/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model;

/**
 *
 * @author BEAST I5
 */
public class NumbersCheckerManager implements NumbersCheckerInterface{

    @Override
    public boolean isNumberValid(int number) throws NumberException {
        int remainder = number / 100;
        
        if(remainder > 0 && remainder < 10){
            boolean isValid = true;
            return isValid;
        }else{
            throw new NumberException(number + "is not 3-digits number");
        }
    }

    @Override
    public boolean isNumberPalindrome(int number) {
        boolean isPalindrome = false;
        
        if(isThisNumberAPalindrome(number))
        {
            isPalindrome = true;
        }
        return isPalindrome;
    }

    private boolean isThisNumberAPalindrome(int number) {
        boolean isAPalindrome = false;
        
        int reversedNumber, firstDigit ,rem, secondDigit,thirdDigits;
        firstDigit = number / 100;
        rem = number % 100;
        secondDigit = rem/ 10;
        thirdDigits = rem % 10;
        
        reversedNumber = thirdDigits*100 + secondDigit*10 + firstDigit;
        
        if(reversedNumber == number){
            isAPalindrome = true;
        }
        
        return isAPalindrome;
    }
    
}
