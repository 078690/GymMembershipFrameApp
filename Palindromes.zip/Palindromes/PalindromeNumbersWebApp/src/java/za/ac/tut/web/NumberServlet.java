/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import za.ac.tut.model.NumbersCheckerInterface;
import za.ac.tut.model.NumbersCheckerManager;

/**
 *
 * @author BEAST I5
 */
public class NumberServlet extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String value = request.getParameter("number");
        Integer number=Integer.parseInt(value);
        
        NumbersCheckerInterface nc1 = new NumbersCheckerManager();
        
        if(nc1.isNumberValid(number)){
            boolean isPalindrome = nc1.isNumberPalindrome(number);
            updateSession(session,isPalindrome);
            
            request.setAttribute("isPalindrome", isPalindrome);
            request.setAttribute("value", value);
            
            RequestDispatcher disp = request.getRequestDispatcher("outcome.jsp");
            disp.forward(request, response);
        }
        
    }

    private void updateSession(HttpSession session, boolean isPalindrome) {
        int tot = (Integer)session.getAttribute("tot");
        tot++;
        session.setAttribute("tot", tot);
        
        if(isPalindrome){
            int cnt = (Integer)session.getAttribute("cnt");
            cnt++;
            session.setAttribute("cnt", cnt);
        }
    }

}
